const express = require('express');
const {
  dashboard,
  login,
  loginUser,
  logOut,
  signup,
  signupUser,
  report,
  sell,
  makeSell,
  topSellingBooks,
  topSpendingCustomers,
  salesPaymentMode,
  invoice,
  sale,
  filterSale,
} = require('../controllers/controllers');

const { checkAuth } = require('../middleware/checkIfAuth');

const router = express.Router();

router.get('/', dashboard);
router.get('/logout', logOut);
router.get('/login', login);
router.post('/login', loginUser);
router.get('/signup', signup);
router.post('/signup', signupUser);
router.get('/report', checkAuth, report);
router.get('/sale', sale);
router.post('/filterSale', filterSale);
router.get('/sell', checkAuth, sell);
router.post('/sell', checkAuth, makeSell);
router.get('/invoice', checkAuth, invoice);
router.get('/topSellingBooks', checkAuth, topSellingBooks);
router.get('/topSpendingCustomers', checkAuth, topSpendingCustomers);
router.get('/salesPaymentMode', checkAuth, salesPaymentMode);
module.exports = router;
